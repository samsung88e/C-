var searchData=
[
  ['isdynamic_118',['IsDynamic',['../classcsci3081_1_1Drone.html#a8af099af9be13a0b99d3aa0888cdbec5',1,'csci3081::Drone::IsDynamic()'],['../classentity__project_1_1IEntity.html#a58d710abd04e533123d033a7ba80f017',1,'entity_project::IEntity::IsDynamic()']]]
];
