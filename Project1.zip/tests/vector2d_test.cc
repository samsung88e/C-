#include "gtest/gtest.h"
#include "../include/delivery_simulation.h"
#include "json_helper.h"
#include <EntityProject/entity.h>
#include <EntityProject/project_settings.h>
#include "json_helper.h"
#include "vector2d.h"
#include "vector3d.h"

#include <iostream>

namespace csci3081 
{
  class Vector2dTest : public ::testing::Test 
  {
  protected:
    virtual void SetUp() 
    {
      Vector2D v0;
      Vector2D v1(0.f,1.f);
      Vector2D v2 = Vector2D(0., 2.);
      Vector2D v3 = Vector2D(0., 4.);
    }
    virtual void TearDown() {}

      Vector2D v0;
      Vector2D v1;
      Vector2D v2;
      Vector2D v3; 
  };


    TEST_F(Vector2dTest, Vector2d_getXYZ_test) 
    {
        EXPECT_EQ(v1.getX(), 0) << "Vector2d_getX_test: fail";
        EXPECT_EQ(v1.getY(), 1) << "Vector2d_getY_test: fail";
    }

    TEST_F(Vector2dTest, Vector2d_operator_test) 
    {
        Vector2D test1 = v0;
        test1 += v1;
        EXPECT_EQ(test1.getY(), v1.getY()) << "Vector2d_operatorvv+_test: fail";

        Vector2D test2 = v3;
        test2 -= v2;
        EXPECT_EQ(test2.getY(), v2.getY()) << "Vector2d_operatorvv-_test: fail";
        
        Vector2D test3 = v2;
        float a = 2;
        test3 *= a;
        EXPECT_EQ(test3.getY(), v3.getY()) << "Vector2d_operatorvv*_test: fail";

        Vector2D test4 = v3;
        float b = 2;
        test4 /= b;
        EXPECT_EQ(test4.getY(), v2.getY()) << "Vector2d_operatorvv/_test: fail";

        Vector2D test5 = v3;
        test5 = Vector2D(v3);
        EXPECT_EQ(test5.getY(), v3.getY()) << "Vector2d_operator=_test: fail";
    }

    TEST_F(Vector2dTest, Vector2d_constortor_test) 
    {   
        EXPECT_EQ(v0.getX(), 0) << "Vector2d_constortor0_test: fail";
        EXPECT_EQ(v1.getX(), 0) << "Vector2d_constortor1_test: fail";
        EXPECT_EQ(v2.getX(), 0) << "Vector2d_constortor2_test: fail";
    }

    TEST_F(Vector2dTest, Vector2d_magnitude_test) 
    {
        float mag = v1.magnitude();

        EXPECT_EQ(mag, 1) << "Vector2d_magnitude_test: fail";
    }

    TEST_F(Vector2dTest, Vector2d_normalize_test) 
    {   
        v0 = v1;
        v1 = v1.Normalize();

        EXPECT_EQ(v1.getY(), v0.getY()) << "Vector2d_normalize_test: fail";
    }
}
