#include "gtest/gtest.h"
#include "../include/delivery_simulation.h"
#include "drone.h"
#include "customer.h"
#include "package.h"
#include "json_helper.h"
#include <EntityProject/entity.h>
#include <EntityProject/project_settings.h>

#include <iostream>

namespace csci3081 
{
  using entity_project::IEntity;

  class PackageTest : public ::testing::Test 
  {
  protected:
    virtual void SetUp() {
      system = dynamic_cast<IDeliverySystem*>(GetEntitySystem("default"));
    }
    virtual void TearDown() {}

    IDeliverySystem* system;
  };
  /*******************************************************************************
   * Test Cases
   ******************************************************************************/
  TEST_F(PackageTest, Constructor) 
  {
    picojson::object obj;
    obj["type"] = picojson::value("package");

    IEntity* entity = system->CreateEntity(obj);
    EXPECT_NE(entity, nullptr);

    Package* package;
    EXPECT_NE(package, nullptr);
    EXPECT_EQ(system->GetEntities().size(), 0);

    system->AddEntity(package);
    EXPECT_EQ(system->GetEntities().size(), 1);
    EXPECT_EQ(picojson::value(system->GetEntities()[0]->GetDetails()).serialize(),
    picojson::value(obj).serialize()); 
  }
  TEST_F(PackageTest, ConstructorDefault) 
  {
    Package* package;
    EXPECT_NE(package, nullptr);
    EXPECT_EQ(package->GetWeight(), 50);
    EXPECT_EQ(package->GetLocation().getX(), 0);
    EXPECT_EQ(package->GetLocation().getY(), 0);
    EXPECT_EQ(package->GetLocation().getZ(), 0);
    EXPECT_NE(package->GetAssignedDrone(), false);
    EXPECT_NE(package->GetPickedUp(), false);
    EXPECT_NE(package->GetIsAssigned(), false);
  }


}  // namespace csci3081
