#include "gtest/gtest.h"
#include "../include/delivery_simulation.h"
#include "drone.h"
#include "customer.h"
#include "package.h"
#include "json_helper.h"
#include <EntityProject/entity.h>
#include <EntityProject/project_settings.h>

#include <iostream>

namespace csci3081 
{
  using entity_project::IEntity;
  // using entity_project::Drone;
  // using entity_project::Customer;
  // using entity_project::Package;

  class DroneTest : public ::testing::Test 
  {
  protected:
    virtual void SetUp() {
      system = dynamic_cast<IDeliverySystem*>(GetEntitySystem("default"));
    }
    virtual void TearDown() {}

    IDeliverySystem* system;
  };
  /*******************************************************************************
   * Test Cases
   ******************************************************************************/
  TEST_F(DroneTest, Constructor) 
  {
    picojson::object obj;
    obj["type"] = picojson::value("drone");

    IEntity* entity = system->CreateEntity(obj);
    EXPECT_NE(entity, nullptr);

    Drone* drone;
    EXPECT_NE(drone, nullptr);
    EXPECT_EQ(system->GetEntities().size(), 0);

    system->AddEntity(drone);
    EXPECT_EQ(system->GetEntities().size(), 1);

    EXPECT_EQ(picojson::value(system->GetEntities()[0]->GetDetails()).serialize(),
    picojson::value(obj).serialize());
  }

  TEST_F(DroneTest, ConstructorDefault) 
  {
    Drone* drone;

    EXPECT_NE(drone, nullptr);

    EXPECT_NE(drone->GetCurrentSpeed(), 0);
    EXPECT_EQ(drone->IsOutOfBattery(), false);
    EXPECT_EQ(drone->GetRemainingBattery(), 0);
    EXPECT_EQ(drone->GetfMaxBatteryCapacity(), 10000.0f);

    EXPECT_NE(drone->IsDynamic(), false);
    EXPECT_NE(drone->GetAssignedPackage(), false);

  }

}  // namespace csci3081
