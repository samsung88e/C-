#include "gtest/gtest.h"
#include "delivery_simulation.h"
#include "drone.h"
#include "customer.h"
#include "package.h"
#include "json_helper.h"
#include <EntityProject/entity.h>
#include <EntityProject/project_settings.h>
#include <iostream>

namespace csci3081 
{
    using entity_project::IEntity;

    // using entity_project::IEntity;
    // using entity_project::Drone;
    // using entity_project::Customer;
    // using entity_project::Package;

    class CustomerTest : public::testing::Test 
    {
    protected:
      virtual void SetUp() 
      {
        system = dynamic_cast<IDeliverySystem*>(GetEntitySystem("default"));
      }
      virtual void TearDown() {}

      IDeliverySystem* system;
    };
    /*******************************************************************************
     * Test Cases
     ******************************************************************************/
    TEST_F(CustomerTest, Constructor_test) 
    {
      picojson::object obj;
      obj["type"] = picojson::value("customer");

      IEntity* entity = system->CreateEntity(obj);
      EXPECT_NE(entity, nullptr);

      Customer* customer;
      EXPECT_NE(customer, nullptr);
      EXPECT_EQ(system->GetEntities().size(), 0);

      system->AddEntity(customer);
      EXPECT_EQ(system->GetEntities().size(), 1);

      EXPECT_EQ(picojson::value(system->GetEntities()[0]->GetDetails()).serialize(),
      picojson::value(obj).serialize());  
    }
    TEST_F(CustomerTest, ConstructorDefault_test) 
    {
      Customer* customer;
      EXPECT_NE(customer, nullptr);
      EXPECT_EQ(customer->GetLocation().getX(), 0);
      EXPECT_EQ(customer->GetLocation().getY(), 0);
      EXPECT_EQ(customer->GetLocation().getZ(), 0);

      EXPECT_NE(customer->IsDynamic(), false);
      EXPECT_NE(customer->GetHasPackage(), false);
    }

}  // namespace csci3081
