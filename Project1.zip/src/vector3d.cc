#include "vector3D.h"
#include <iostream>
#include <cmath>

namespace csci3081 {

Vector3D::Vector3D() {
    vector3.push_back(0.f);
    vector3.push_back(0.f);
    vector3.push_back(0.f);
}

Vector3D::Vector3D(float x, float y, float z) {
    vector3.push_back(x);
    vector3.push_back(y);
    vector3.push_back(z);

}

Vector3D::Vector3D(std::vector<float> vec) {
    for (int i = 0; i < vec.size(); i++) {
     vector3.push_back(vec.at(i));
    }
}


void Vector3D::SetVector(float x, float y, float z) {
    vector3.at(0) = x;
    vector3.at(1) = y;
    vector3.at(2) = z;
}


std::vector<float> Vector3D::GetVector() {
    return vector3;
}

float Vector3D::GetMagnitude() {
    return sqrt(pow(vector3.at(0), 2) + pow(vector3.at(1), 2) + pow(vector3.at(2), 2));
}

std::vector<float> Vector3D::GetNormalizedVector() {
    float mag = this->GetMagnitude();
    std::vector<float> normVector;

    if(mag == 0) {   
        for (int i = 0; i < vectorSize; i++) {
        normVector.push_back(0);
        }
        return normVector;
    }

    for (int i = 0; i < vectorSize; i++) {
        normVector.push_back(vector3.at(i) / mag);
    }

    return normVector;
}

float Vector3D::DotProduct(Vector3D& vec3) {
    std::vector<float> a = vector3;
    std::vector<float> b = vec3.GetVector();

    float dotProduct = 0;

    for(int i = 0; i < vectorSize; i++) {
        dotProduct += a.at(i) * b.at(i);
    }

    return dotProduct;

}

std::vector<float> Vector3D::AddVector(Vector3D& vec) {
    std::vector<float> vect = vec.GetVector();
    std::vector<float> add{0.f, 0.f, 0.f};

    for(int i = 0; i < vectorSize; i++) {
        add.at(i) = vector3.at(i) + vect.at(i);
    }

    return add;
}

std::vector<float> Vector3D::SubtractVector(Vector3D& vec) {
    std::vector<float> vect = vec.GetVector();
    std::vector<float> sub{0.f, 0.f, 0.f};

    for(int i = 0; i < vectorSize; i++) {
        sub.at(i) = vector3.at(i) - vect.at(i);
    }

    return sub;
}

//Currently dosn't really do what 
bool Vector3D::Equals(Vector3D& vec) {
    std::vector<float> vect = vec.GetVector();

    bool isEqual = true;

    for(int i = 0; i < vectorSize; i++) {
        if(fabs(vector3.at(i) - vect.at(i)) > 0.5f) {
            isEqual = false;
        }
    }

    return isEqual;


}

}