#include "package.h"


namespace csci3081 {

Package::Package(std::vector<float> position, std::vector<float> direction, const picojson::object& details) {

    for(int i = 0; i < position.size(); i++)
    {
        this->position[i] = position[i];
        this->direction[i] = direction[i];
    }

    
    name = "package";
    isDelivered = false;

    id = GenerateId();


  // The following line saves the json object in the details_ member variable
  // from the EntityBase class, in order to return it later in GetDetails()
    details_ = details;
}


int Package::GetId() const {
  // TODO: This is just a stub for compilation
  return id;
}

const std::string& Package::GetName() {
  // TODO for lab10: What should this return?
  return name;
}

const std::vector<float>& Package::GetPosition() const {
  // TODO for lab10: What should this return?
  return position;
}

const std::vector<float>& Package::GetDirection() const {
  // TODO for lab10: what should this return?
  return direction;
}

float Package::GetRadius() const {
  // TODO: This is just a stub for compilation
  return 1;
}

int Package::GetVersion() const {
  // TODO: This is just a stub for compilation
  return 0;
}

bool Package::IsDynamic() const {
  // TODO: This is just a stub for compilation
  return true;
}

void Package::SetCustomer(Customer* customer) {
  this->customer = customer;
}

void Package::SetIsDelivered(bool isDelivered) {
  this->isDelivered = isDelivered;
}

bool Package::IsDelivered() {
  return isDelivered;
}

void Package::SetPosition(std::vector<float> position) {
  this->position = position;
}

Customer* Package::GetCustomer() {
  return customer;
}




};