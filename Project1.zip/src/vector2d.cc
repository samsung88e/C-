#include "vector2D.h"
#include <iostream>
#include <cmath>

namespace csci3081 {

Vector2D::Vector2D() {
    vector2.push_back(0.f);
    vector2.push_back(0.f);
}

Vector2D::Vector2D(float x, float y) {
    vector2.push_back(x);
    vector2.push_back(y);
}


void Vector2D::SetVector(float x, float y) {
    vector2.at(0) = x;
    vector2.at(1) = y;
}


std::vector<float> Vector2D::GetVector() {
    return vector2;
}

float Vector2D::GetMagnitude() {
    return sqrt(pow(vector2.at(0), 2) + pow(vector2.at(1), 2));
}

std::vector<float> Vector2D::GetNormalizedVector() {
    float mag = this->GetMagnitude();
    std::vector<float> normVector;

    if(mag == 0) {   
        for (int i = 0; i < vectorSize; i++) {
        normVector.push_back(0);
        }
        return normVector;
    }

    for (int i = 0; i < vectorSize; i++) {
        normVector.push_back(vector2.at(i) / mag);
    }

    return normVector;
}

float Vector2D::DotProduct(Vector2D& vec2) {
    std::vector<float> a = vector2;
    std::vector<float> b = vec2.GetVector();

    float dotProduct = 0;

    for(int i = 0; i < vectorSize; i++) {
        dotProduct += a.at(i) * b.at(i);
    }

    return dotProduct;

}

}