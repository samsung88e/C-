#include "robot.h"

namespace csci3081{
    Robot::Robot(std::vector<float> position, std::vector<float> direction, float speed, const picojson::object& details) {
        for(int i = 0; i < position.size(); i++){
            this->position[i] = position[i];
            this->direction[i] = direction[i];  
        }

        name = "pkgRobot";
        hasDelivery = false;
        hasPackage = false;
        details_ = details;

        this->speed = speed;

        id = GenerateId();
    }

    int Robot::GetId() const{
        return id;
    }

    const std::string& Robot::GetName() {
        return name;
    }

    const std::vector<float>& Robot::GetPosition() const {
        return position;
    }

    const std::vector<float>& Robot::GetDirection() const {
        return direction;
    }

    float Robot::GetRadius() const {
  // TODO: This is just a stub for compilation
  return 1;
}

int Robot::GetVersion() const {
  // TODO: This is just a stub for compilation
  return 0;
}

bool Robot::IsDynamic() const {
  // TODO: This is just a stub for compilation
  return true;
}

void Robot::AddPoint(std::vector<float> point) {
  points.push(point);
}


void Robot::RemovePoint() {
  points.pop();
}

void Robot::MoveToPoints(float dt) {
  if(points.empty()) { return; }

  Vector3D pos(position);
  Vector3D dest(points.front());
  Vector3D dir(dest - pos);

  Vector3D normDir = dir.GetNormalizedVector();

  for (int i = 0; i < direction.size(); i++) {
    direction.at(i) = normDir.GetVector()[i];
  }

  Vector3D motionVector = normDir * speed * dt;

  if((dest-pos).GetMagnitude() < speed*dt){
    position = points.front();
    points.pop();
  }
  else{
    for (int i = 0; i < position.size(); i++) {
      position.at(i) = position.at(i) + motionVector.GetVector()[i];
    }
  }

  if (hasPackage) {
    package->SetPosition(position);
  }

}

bool Robot::HasDelivery() {
  return hasDelivery;
}

void Robot::SetHasDelivery(bool hasDelivery) {
  this->hasDelivery = hasDelivery;
}

void Robot::SetPackage(Package* package) {
  this->package = package;
}



void Robot::SetHasPackage(bool hasPackage) {
  this->hasPackage = hasPackage;
}

bool Robot::HasPackage() {
  return hasPackage;
}

void Robot::PickupPackage(AEntitySubject* sub) {
  hasPackage = true;

  picojson::value val;
  std::string json = "{\"type\": \"notify\", \"value\": \"en route\"}";
  picojson::parse(val, json);
  sub->Notify(val, *this);

  //Send Path to Observer
  updateObserverPath(sub);

}

void Robot::DeliverPackage(AEntitySubject* sub) {
  hasPackage = false;
  hasDelivery = false;
  package->SetIsDelivered(true);

  picojson::value val;
  const char* json = "{\"type\": \"notify\", \"value\": \"delivered\"}";
  picojson::parse(val, json);
  sub->Notify(val, *this);
}

Package* Robot::GetPackage() {
  return package;
}

void Robot::Idle(AEntitySubject* sub) {
  picojson::value val;
  const char* json = "{\"type\": \"notify\", \"value\": \"idle\"}";
  picojson::parse(val, json);
  sub->Notify(val, *this);
}

//TEMP
void Robot::addPathVal(picojson::value val) {
  pathVals.push_back(val);
}

void Robot::updateObserverPath(AEntitySubject* sub) {
  picojson::value val;
  std::string json;

  if(!hasPackage) {
    std::string str = pathVals.at(0).serialize();
    json = "{\"type\": \"notify\", \"value\": \"moving\", \"path\":" + str + "}";
    picojson::parse(val, json);
    sub->Notify(val, *this);
  }
  if(hasPackage) {
    std::string str = pathVals.at(1).serialize();
    json = "{\"type\": \"notify\", \"value\": \"moving\", \"path\":" + str + "}";
    picojson::parse(val, json);
    sub->Notify(val, *this);
  }
}

    
}