#include "battery.h"


namespace csci3081 {


Battery::Battery(float charge = 0.f, float chargeSize = 100.f, float chargeRate = 1.f, float dechargeRate = 1.f) {
    this->charge = charge;
    this->chargeSize = chargeSize;
    this->chargeRate = chargeRate;
    this->dechargeRate = dechargeRate;
}

void Battery::Charge() {
    if (charge < chargeSize) {
        charge += chargeRate;
    }
    return;
}

void Battery::Decharge() {
    if (charge > 0) {
        charge -= dechargeRate;
    }
    return;
}

float Battery::GetCharge() {
    return charge;
}

}