#include "customer.h"


namespace csci3081 {

Customer::Customer(std::vector<float> position, std::vector<float> direction,
                                        const picojson::object& details) {

    for(int i = 0; i < position.size(); i++)
    {
        this->position[i] = position[i];
    }
  
    name = "customer";

    id = GenerateId();


  // The following line saves the json object in the details_ member variable
  // from the EntityBase class, in order to return it later in GetDetails()
    details_ = details;
}


int Customer::GetId() const {
  return id;
}

const std::string& Customer::GetName() {
  return name;
}

const std::vector<float>& Customer::GetPosition() const {
  return position;
}

const std::vector<float>& Customer::GetDirection() const {
  return direction;
}

float Customer::GetRadius() const {
  // TODO: This is just a stub for compilation
  return 1;
}

int Customer::GetVersion() const {
  // TODO: This is just a stub for compilation
  return 0;
}

bool Customer::IsDynamic() const {
  return true;
}

}