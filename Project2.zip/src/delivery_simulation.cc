#include "delivery_simulation.h"
#include "entity_base.h"
#include "json_helper.h"
#include "drone.h"
#include "customer.h"
#include "package.h"
#include "robot.h"

namespace csci3081 {

DeliverySimulation::DeliverySimulation() {
	compositeFactory = new CompositeFactory();
	entitySubject = new AEntitySubject();
}

DeliverySimulation::~DeliverySimulation() {
	delete compositeFactory;
	delete entitySubject;
}

IEntity* DeliverySimulation::CreateEntity(const picojson::object& val) {
	return compositeFactory->CreateEntity(val);
}

void DeliverySimulation::AddFactory(IEntityFactory* factory) {
	compositeFactory->AddFactory(factory);
}

void DeliverySimulation::AddEntity(IEntity* entity) { 
  	entities_.push_back(entity);
}

void DeliverySimulation::SetGraph(const IGraph* graph) {
	this->graph = graph;
}

void DeliverySimulation::ScheduleDelivery(IEntity* package, IEntity* dest) {
	bool deliveryAssigned = false;

	for (int i = 0; i < entities_.size(); i++) {
		if (JsonHelper::GetString(entities_.at(i)->GetDetails(), "type") == "drone") {
			Drone* drn = dynamic_cast<Drone*>(entities_.at(i));
			if (!drn->HasDelivery()) {
				std::vector<std::vector<float>> pkgToDest = graph->GetPath(package->GetPosition(), dest->GetPosition());
				std::vector<std::vector<float>> drnToPkg = graph->GetPath(drn->GetPosition(), package->GetPosition());
				//TEMP
				drn->addPathVal(JsonHelper::EncodeArray(drnToPkg));
				drn->addPathVal(JsonHelper::EncodeArray(pkgToDest));
				drn->updateObserverPath(entitySubject);
				//END TEMP
				for (std::vector<float> point : drnToPkg) {
					drn->AddPoint(point);
				}
				for (std::vector<float> point : pkgToDest) {
					drn->AddPoint(point);
				}
				Package* pkg = dynamic_cast<Package*>(package);
				Customer* cstmr = dynamic_cast<Customer*>(dest);
				pkg->Scheduled(entitySubject);
				pkg->SetCustomer(cstmr);
				drn->SetPackage(pkg);
				drn->SetHasDelivery(true);
				deliveryAssigned = true;
				break;
			}
			
		}

		else if (JsonHelper::GetString(entities_.at(i)->GetDetails(), "type") == "robot") {
			Robot* robot = dynamic_cast<Robot*>(entities_.at(i));
			if (!robot->HasDelivery()) {
				std::vector<float> packagePosition = package->GetPosition();
				std::vector<float> customerPosition = dest->GetPosition();
				std::vector<std::vector<float>> pkgToDest = graph->GetPath(package->GetPosition(), dest->GetPosition());
				std::vector<std::vector<float>> robotToPkg = graph->GetPath(robot->GetPosition(), package->GetPosition());
				//TEMP
				robot->addPathVal(JsonHelper::EncodeArray(robotToPkg));
				robot->addPathVal(JsonHelper::EncodeArray(pkgToDest));
				robot->updateObserverPath(entitySubject);
				//END TEMP
				for (std::vector<float> point : robotToPkg) {
					robot->AddPoint(point);
				}
				for (std::vector<float> point : pkgToDest) {
					robot->AddPoint(point);
				}
				Package* pkg = dynamic_cast<Package*>(package);
				Customer* cstmr = dynamic_cast<Customer*>(dest);
				pkg->SetCustomer(cstmr);
				robot->SetPackage(pkg);
				robot->SetHasDelivery(true);
				deliveryAssigned = true;
				break;
			}
			
		}

		
	}

	if(!deliveryAssigned && package != nullptr && dest != nullptr) {
			Deliveries delivery;
			delivery.dest = dest;
			delivery.package = package;
			deliveryQueue.push(delivery);
	}
}

void DeliverySimulation::AddObserver(IEntityObserver* observer) {
	entitySubject->Attach(observer);
}

void DeliverySimulation::RemoveObserver(IEntityObserver* observer) {
	entitySubject->Detach(observer);
}

const std::vector<IEntity*>& DeliverySimulation::GetEntities() const { return entities_; }

void DeliverySimulation::Update(float dt) {
	if (entities_.empty()) {return;}
	for (int i = 0; i < entities_.size(); i++) {
		if (JsonHelper::GetString(entities_.at(i)->GetDetails(), "type") == "drone") {
			Drone* drn = dynamic_cast<Drone*>(entities_.at(i));
			
			if(drn->HasDelivery()) {
				Package* pkg = drn->GetPackage();
				Customer* cstmr = pkg->GetCustomer();

				drn->MoveToPoints(dt);

				Vector3D drnPosition = drn->GetPosition();
				Vector3D pkgPosition = pkg->GetPosition();
				Vector3D cstmrPosition = cstmr->GetPosition();

				if(drnPosition.Equals(pkgPosition) && !drn->HasPackage()) {
					drn->PickupPackage(entitySubject);
				}

				if(pkgPosition.Equals(cstmrPosition) && drn->HasPackage()) {
					drn->DeliverPackage(entitySubject);
					std::vector<float> farAway(3, 100000.f);
					pkg->SetPosition(farAway);
					if(!deliveryQueue.empty()) {
						IEntity* dest = deliveryQueue.front().dest;
						IEntity* package = deliveryQueue.front().package;
						deliveryQueue.pop();
						ScheduleDelivery(package, dest);
					}
					else {
						drn->Idle(entitySubject);
					}
				}
			
			}


			
		}
		else if (JsonHelper::GetString(entities_.at(i)->GetDetails(), "type") == "robot") {
			Robot* robot = dynamic_cast<Robot*>(entities_.at(i));
			
			if(robot->HasDelivery()) {
				Package* pkg = robot->GetPackage();
				Customer* cstmr = pkg->GetCustomer();

				robot->MoveToPoints(dt);

				Vector3D robotPosition = robot->GetPosition();
				Vector3D pkgPosition = pkg->GetPosition();
				Vector3D cstmrPosition = cstmr->GetPosition();

				if(robotPosition.Equals(pkgPosition) && !robot->HasPackage()) {
					robot->PickupPackage(entitySubject);
				}

				if(pkgPosition.Equals(cstmrPosition) && robot->HasPackage()) {
					robot->DeliverPackage(entitySubject);
					std::vector<float> farAway(3, 100000.f);
					pkg->SetPosition(farAway);
					if(!deliveryQueue.empty()) {
						IEntity* dest = deliveryQueue.front().dest;
						IEntity* package = deliveryQueue.front().package;
						deliveryQueue.pop();
						ScheduleDelivery(package, dest);
					}
					else {
						robot->Idle(entitySubject);
					}
				}
			
			}


			
		}
	}
}


// DO NOT MODIFY THE FOLLOWING UNLESS YOU REALLY KNOW WHAT YOU ARE DOING
void DeliverySimulation::RunScript(const picojson::array& script, IEntitySystem* system) const {
  JsonHelper::PrintArray(script);
  IDeliverySystem* deliverySystem = dynamic_cast<IDeliverySystem*>(system);
	if (deliverySystem) {

	    // To store the unadded entities_
	    std::vector<IEntity*> created_entities;

		for (unsigned int i=0; i < script.size(); i++) {
			const picojson::object& object = script[i].get<picojson::object>();
			const std::string cmd = object.find("command")->second.get<std::string>();
			const picojson::object& params = object.find("params")->second.get<picojson::object>();
			// May want to replace the next few if-statements with an enum
			if (cmd == "createEntity") {
				IEntity* entity = NULL;
				entity = deliverySystem->CreateEntity(params);
				if (entity) {
					created_entities.push_back(entity);
				} else {
					std::cout << "Null entity" << std::endl;
				}
			}
			else if (cmd == "addEntity") {
				int ent_index = static_cast<int>(params.find("index")->second.get<double>());
				if (ent_index >= 0 && ent_index < created_entities.size()) {
					deliverySystem->AddEntity(created_entities[ent_index]);
				}
			}
			else if (cmd == "scheduleDelivery" ) {
				int pkg_index = static_cast<int>(params.find("pkg_index")->second.get<double>());
				int dest_index = static_cast<int>(params.find("dest_index")->second.get<double>());
				if (pkg_index >= 0 && pkg_index < system->GetEntities().size()) {
					IEntity* pkg = deliverySystem->GetEntities()[pkg_index];
					if (dest_index >= 0 && pkg_index < system->GetEntities().size()) {
						IEntity* cst = system->GetEntities()[dest_index];
						if (pkg && cst) {
							deliverySystem->ScheduleDelivery(pkg, cst);
						}
					}
				}
				else {
					std::cout << "Failed to schedule delivery: invalid indexes" << std::endl;
				}
			}
		}
	}
}

}
